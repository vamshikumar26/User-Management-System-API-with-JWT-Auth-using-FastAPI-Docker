MONGO_URI="#paste your mongodb url"

DATABASE_NAME="paste your database name"